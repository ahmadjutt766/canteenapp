package com.example.canteenapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class canteen_DB extends AppCompatActivity {

    private RecyclerView.Adapter mAdapter;
    RecyclerView recyclerView;
    private FirebaseDatabase mDatabase;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_canteen__d_b);
        recyclerView = findViewById(R.id.cantene_list);
        RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(this);
        recyclerView.setLayoutManager(layoutManager);
       Query myRef = mDatabase.getReference("item_list");
      //  mDatabase =FirebaseDatabase.getInstance().getReference().child("item_list");
        Toast.makeText(getApplicationContext(), "OKAT", Toast.LENGTH_LONG).show();
        myRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                ArrayList<Items> data = new ArrayList<>();
                if (dataSnapshot.exists()) {
                    for (DataSnapshot postSnapshot : dataSnapshot.getChildren()) {
                        Items items = postSnapshot.getValue(Items.class);
                        data.add(items);
                    }
                    mAdapter = new RecycleAdapter(canteen_DB.this, data);
                    recyclerView.setAdapter(mAdapter);
                    Toast.makeText(getApplicationContext(), "databaseConfirmed", Toast.LENGTH_LONG).show();

                    return;
                }
                Toast.makeText(getApplicationContext(), "Not Found", Toast.LENGTH_LONG).show();


            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Toast.makeText(getApplicationContext(), "databaseError.getMessage()", Toast.LENGTH_LONG).show();
            }
        });



    }
    @Override
    public boolean onSupportNavigateUp() {
        onBackPressed();
        return true;
    }
}