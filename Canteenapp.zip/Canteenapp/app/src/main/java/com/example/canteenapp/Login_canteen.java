package com.example.canteenapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

public class Login_canteen extends AppCompatActivity {

    EditText et_email,et_password;
    Button btn_login;
    private FirebaseAuth auth;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
         et_email = findViewById(R.id.ET_email);
         et_password =findViewById(R.id.ET_password);
         btn_login = findViewById(R.id.login);

         auth = FirebaseAuth.getInstance();

        if(auth.getCurrentUser()!=null){
            Toast.makeText(getApplicationContext(), "Already User Session Existed", Toast.LENGTH_SHORT).show();
            finish();
        }

         btn_login.setOnClickListener(new View.OnClickListener() {
             @Override
             public void onClick(View v) {
                 String email = et_email.getText().toString();
                 final String password = et_password.getText().toString();
                 if (TextUtils.isEmpty(email)) {
                     Toast.makeText(getApplicationContext(), "Enter email address!", Toast.LENGTH_SHORT).show();
                     return;
                 }
                 if (TextUtils.isEmpty(password)) {
                     Toast.makeText(getApplicationContext(), "Enter password!", Toast.LENGTH_SHORT).show();
                     return;
                 }
                 auth.signInWithEmailAndPassword(email,password).addOnCompleteListener(Login_canteen.this, new OnCompleteListener<AuthResult>() {
                     @Override
                     public void onComplete(@NonNull Task<AuthResult> task) {
                         if (task.isSuccessful()) {
                             Toast.makeText(Login_canteen.this, "Authentication",Toast.LENGTH_LONG).show();
                             Intent intent = new Intent(Login_canteen.this, canteen_view.class);
                             startActivity(intent);
                             finish();

                         }

                         else {

                                 Toast.makeText(Login_canteen.this, "Authentication failed, check your email and password",
                                         Toast.LENGTH_LONG).show();


                         }
                     }
                 });
             }
         });
    }
}