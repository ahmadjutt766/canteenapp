package com.example.canteenapp;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class RecycleAdapter extends RecyclerView.Adapter<RecycleAdapter.MyViewHolder> {
    private Context context;
    private List<Items> list;

    public RecycleAdapter(Context context, List<Items> list) {

        this.context = context;
        this.list = list;

    }

    @NonNull
    @Override
    public RecycleAdapter.MyViewHolder onCreateViewHolder(ViewGroup parent,
                                                             int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.canteen_item, parent, false);
        return new RecycleAdapter.MyViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {
        holder.name.setText(list.get(position).getName()+":->"+list.get(position).getDescription());

        holder.cost.setText(list.get(position).getCost()+":    IN STOCK"+list.get(position).getActive());
    }




    @Override
    public int getItemCount() {
        return list.size();
    }

    static class MyViewHolder extends RecyclerView.ViewHolder {

        TextView name, cost;

        View view;

        MyViewHolder(View v) {
            super(v);
            name = v.findViewById(R.id.name);
            cost = v.findViewById(R.id.image);

            view = v.findViewById(R.id.relativeLayout);
        }
    }
}
