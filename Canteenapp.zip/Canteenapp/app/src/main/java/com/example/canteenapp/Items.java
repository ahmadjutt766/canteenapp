package com.example.canteenapp;

public class Items {

    private String active;
    private String cost;
    private String description;
    private String id;
    private String name;
    private String time_to_get_ready;
    public Items() {

    }

    public Items(String active, String cost, String description, String id, String name, String time_to_get_ready) {
        this.active = active;
        this.cost = cost;
        this.description = description;
        this.id = id;
        this.name = name;
        this.time_to_get_ready = time_to_get_ready;
    }
    public String getActive() {
        return active;
    }

    public void setActive(String active) {
        this.active = active;
    }

    public String getCost() {
        return cost;
    }

    public void setCost(String cost) {
        this.cost = cost;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getTime_to_get_ready() {
        return time_to_get_ready;
    }

    public void setTime_to_get_ready(String time_to_get_ready) {
        this.time_to_get_ready = time_to_get_ready;
    }



   /* "active" : 24,
            "cost" : 20,
            "description" : "Sprite [LEMON & LIME FLAVOR 250-ML]",
            "id" : "0",
            "name" : "Cold Drink [Regular]",
            "time_to_get_ready" : "2-MIN"
*/




}
